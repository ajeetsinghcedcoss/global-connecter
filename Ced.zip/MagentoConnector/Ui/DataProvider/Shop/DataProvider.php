<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Fyndiq
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\MagentoConnector\Ui\DataProvider\Shop;

use Magento\Ui\DataProvider\AbstractDataProvider;

class DataProvider extends AbstractDataProvider
{
    /**
     * @var $collection
     */
    public $collection;

    /**
     * @var $addFieldStrategies
     */
    public $addFieldStrategies;

    /**
     * @var $addFilterStrategies
     */
    public $addFilterStrategies;

    public $config;

    public $authSession;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param array $addFieldStrategies
     * @param array $addFilterStrategies
     * @param \Ced\MagentoConnector\Helper\Config $config
     * @param \Magento\Backend\Model\Auth\Session $authSession
     * @param \Ced\MagentoConnector\Model\ResourceModel\Marketplace\Collection $collection
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        \Ced\MagentoConnector\Helper\Config $config,
        \Magento\Backend\Model\Auth\Session $authSession,
        \Ced\MagentoConnector\Model\ResourceModel\Marketplace\Collection $collection,
        $addFieldStrategies = [],
        $addFilterStrategies = [],
        $meta = [],
        $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->config = $config;
        $this->authSession = $authSession;
        $this->collection = $collection;
        $this->addFieldStrategies = $addFieldStrategies;
        $this->addFilterStrategies = $addFilterStrategies;
    }

    /**
     * @return array
     */
    public function getData()
    {
        if (!$this->getCollection()->isLoaded()) {
            $this->getCollection()->load();
        }
        $items = $this->getCollection()->getData();
        return $items;

        $data = $this->config->getAllDetails();
        $userEmail = $this->authSession->getUser()->getEmail();
        if (isset($data['email']) && !empty($data['email'])) {
            $userEmail = $data['email'];
        }

        $return[1] = [
            'store_id' =>  $data['storeID'],
            'email' =>  $userEmail,
            'token_type' =>  $data['token_type']
        ];
        return $return;
    }

}
