<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_MagentoConnector
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\MagentoConnector\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Setup\Exception;

class VarificationApi extends \Magento\Framework\App\Helper\AbstractHelper
{

    const URL = "http://localhost/m2.4/2.4.2/pub/rest/V1/user/authentication/";
    public $scopeConfig;
    public $logger;

    public function __construct(
        \Ced\MagentoConnector\Helper\Logger $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        Context $context
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
        parent::__construct($context);
    }

    public function varification($data)
    {
        $finaleData = $data;
        $requestParameters = json_encode($finaleData);
        //@codingStandardsIgnoreStart
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, self::URL);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestParameters);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($requestParameters))
        );
        $response = curl_exec($ch);
        $response = json_decode($response, true);
        curl_close($ch);
        return $response;
    }

    public function allowedMarketplace()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $secureUrl = $this->scopeConfig->getValue("web/secure/base_url");
        $unsecureUrl = $this->scopeConfig->getValue("web/unsecure/base_url");
        $data = [
            'store_url' => $secureUrl,
            'unsecure_store_url' => $unsecureUrl
        ];
        $finaleData = $data;
        $requestParameters = json_encode($finaleData);
        //@codingStandardsIgnoreStart
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, self::URL);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestParameters);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($requestParameters))
        );
        $response = curl_exec($ch);
        $response = json_decode($response, true);
        curl_close($ch);
        return $response;
    }
}
