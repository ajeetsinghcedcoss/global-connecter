<?php

namespace Ced\MagentoConnector\Block\Adminhtml\Marketplace;

class MList extends \Magento\Backend\Block\Template
{
    public $_template="marketplace/list.phtml";

    /**
     * Object Manger
     * @var  \Magento\Framework\ObjectManagerInterface $objectManager
     */
    public $objectManager;

    public $collectionFactory;

    public $varificationApi;

    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Ced\MagentoConnector\Model\ResourceModel\Marketplace\CollectionFactory $collectionFactory
     * @param \Ced\MagentoConnector\Helper\VarificationApi $varificationApi
     * @param \Magento\Backend\Block\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Ced\MagentoConnector\Model\ResourceModel\Marketplace\CollectionFactory $collectionFactory,
        \Ced\MagentoConnector\Helper\VarificationApi $varificationApi,
        \Magento\Backend\Block\Template\Context $context,
        array $data = []
    ) {
        $this->objectManager = $objectManager;
        $this->collectionFactory = $collectionFactory;
        $this->varificationApi = $varificationApi;
        parent::__construct($context, $data);
    }

    /**
     * Magento Contructor
     * @return void
     */
    public function _construct()
    {
        parent::_construct();
        $this->setTemplate($this->_template);
    }

    public function getMarketplaceUrl($str, $param = []) {
        return $this->getUrl($str, $param);
    }

    public function getList()
    {
        $data = ['data' => ['integration_list' => true]];
        $returnData = $this->varificationApi->varification($data);
        return isset($returnData[0]) ? $returnData[0] : $returnData;
    }

    public function allowedList()
    {
        $returnData = $this->varificationApi->allowedMarketplace();
        return isset($returnData[0]) ? $returnData[0] : $returnData;
    }

    public function getActiveList($code, $value)
    {
        $collection = $this->collectionFactory
            ->create()
            ->addFieldToFilter($code,$value);
        if ($code == 'code') {
            $collection->addFieldToFilter('status',1);
        }
        return $collection->getFirstItem();
    }
}
