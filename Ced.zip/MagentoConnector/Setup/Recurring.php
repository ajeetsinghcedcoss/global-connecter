<?php

namespace Ced\MagentoConnector\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class Recurring implements InstallSchemaInterface
{

    protected $logger;
    protected $apiEndPoint;
    protected $config;

    protected $collectionFactory;

    public function __construct(
        \Ced\MagentoConnector\Helper\Logger $logger,
        \Ced\MagentoConnector\Helper\ApiEndPoint $apiEndPoint,
        \Ced\MagentoConnector\Model\ResourceModel\Marketplace\CollectionFactory $collectionFactory,
        \Ced\MagentoConnector\Helper\Config $config
    ) {
        $this->logger = $logger;
        $this->apiEndPoint = $apiEndPoint;
        $this->collectionFactory = $collectionFactory;
        $this->config = $config;
    }

    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $data = [];
        $lists = $this->collectionFactory->create()->addFieldToFilter('is_connected',1);
        if($lists) {
            foreach ($lists as $list) {
                $data['code'] = $list->getCode();
                $data['token_type'] = $list->getTokenType();
                $data['storeurl'] = $list->getStoreUrl();
                $data['setup_upgrade'] = true;
                $response = $this->apiEndPoint->sendTokenByCurl($data);
                $this->logger->logger(
                    'Setup Upgrade',
                    'Installer',
                    "Response . ".json_encode($response),
                    'Installer is running  '.$list->getMarketPlace()
                );
            }
        }
        $setup->endSetup();
    }
}
