<?php
namespace Ced\MagentoConnector\Model\Api;

use Ced\MagentoConnector\Api\TokenInterface;
use \Ced\MagentoConnector\Model\Source\TokenType\Options;

class Token implements TokenInterface
{
    public $logger;

    public $config;

    public $dataHelper;

    public $integrationToken;

    public function __construct(
        \Ced\MagentoConnector\Helper\Logger $logger,
        \Ced\MagentoConnector\Helper\Config $config,
        \Ced\MagentoConnector\Helper\Data $dataHelper,
        \Ced\MagentoConnector\Helper\IntegrationToken $integrationToken
    ) {
        $this->logger = $logger;
        $this->config = $config;
        $this->dataHelper = $dataHelper;
        $this->integrationToken = $integrationToken;
    }

    /**
     * @param string $userid
     * @return mixed|string
     */
    public function getRefreshToken($userid)
    {
        $returnResponse = [];
        $magentoMarketplaceModel = $this->config->getModelByUserId($userid);
        if ($magentoMarketplaceModel && $magentoMarketplaceModel->getIsConnected()) {
            $userID = $magentoMarketplaceModel->getUserId();
            $code = $magentoMarketplaceModel->getCode();
            $response = [];
            if ($userID == $userid) {
                $allDetails = $this->config->getAllDetails($code);
                if (isset($allDetails['token_type']) &&
                    $allDetails['token_type'] == Options::INTEGRATION_TOKEN) {
                    $email = $allDetails['email'];
                    $response = $this->integrationToken->genrateIntegrationToken($email);
                } else {
                    $returnResponse = ['error' => ['message' => "User Password."]];
                }

                if (isset($response['token'])) {
                    $this->dataHelper->setConfig($code,['access_token' => $response['token']]);
                    $returnResponse['success']['token'] = $response['token'];
                    if (isset($allDetails['token_type']) &&
                        $allDetails['token_type'] != Options::INTEGRATION_TOKEN) {
                        $returnResponse['success']['expireTime'] = $this->config->adminTokenTime();
                    }
                } elseif (isset($response['message'])) {
                    $returnResponse = ['error' => ['message' => $response['message']]];
                } else {
                    $returnResponse = ['error' => ['message' => $response]];
                }
            } else {
                $returnResponse = ['error' => ['message' => "Invalid User Id."]];
            }
        } else {
            $returnResponse = ['error' => ['message' => "you are not connected or Invalid User Id."]];
        }
        return [$returnResponse];
    }
}
