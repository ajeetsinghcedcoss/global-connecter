<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_MagentoConnector
 * @author      CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license     http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\MagentoConnector\Controller\Adminhtml\Connect;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{
    const ADMIN_RESOURCE = 'Ced_MagentoConnector::MagentoConnector';
    /**
     * ResultPageFactory
     * @var PageFactory
     */
    public $resultPageFactory;
    public $resultFactory;
    public $marketplaceFactory;
    public $config;

    /**
     * @param Context $context
     * @param \Magento\Framework\Controller\ResultFactory $resultFactory
     * @param \Ced\MagentoConnector\Helper\Config $config
     * @param \Ced\MagentoConnector\Model\MarketplaceFactory $marketplaceFactory
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Controller\ResultFactory $resultFactory,
        \Ced\MagentoConnector\Helper\Config $config,
        \Ced\MagentoConnector\Model\MarketplaceFactory $marketplaceFactory,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->resultFactory = $resultFactory;
        $this->marketplaceFactory = $marketplaceFactory;
        $this->config = $config;
    }

    /**
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $redirect = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);
        $param = $this->getRequest()->getParam('re-connect');
        $code = $this->getRequest()->getParam('code');
        $marketPlace = $this->getRequest()->getParam('market_place');
        if($code) {
            $this->_session->setMarkeplaceCode($code);
            $this->_session->setMarkeplaceName($marketPlace);
        }

        if ($this->config->isConnected($code) && !$param) {
            $this->messageManager->addSuccessMessage('Connected Successfully.');
            return $redirect->setPath('*/*/success');
        }

        $param = $this->getRequest()->getParams();
        if(isset($code)) {
            $this->_session->setMarkeplaceCode($code);
            $this->_session->setMarkeplaceName($marketPlace);
            $model = $this->marketplaceFactory->create()->get($marketPlace, 'code');
            if($model && $model->getId()) {
                $this->messageManager->addSuccessMessage('Already Connected .');
                return $redirect->setPath('*/*/index');
            }
        }

        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Ced_MagentoConnector::MagentoConnector');
        $resultPage->getConfig()->getTitle()->prepend(__(' Connecter Information'));
        return $resultPage;
    }
}
