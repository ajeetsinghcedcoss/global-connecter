<?php
namespace Ced\VendorVarification\Api;

interface AuthenticationInterface
{
    /**
     * POST for test api
     * @param mixed $data
     * @return mixed|string
     */

    public function setData($data);

    /**
     * @param mixed $data
     * @return mixed|string
     */
    public function endpoints($data);
}
