<?php
namespace Ced\VendorVarification\Model\Api;

use Ced\VendorVarification\Api\AuthenticationInterface;

class Authentication implements AuthenticationInterface
{

    public $factory;

    public $authenticationFactory;

    public function __construct(
        \Ced\VendorVarification\Model\AuthenticationFactory $authenticationFactory,
        \Magento\Config\Model\Config\Factory $factory
    ) {
        $this->factory = $factory;
        $this->authenticationFactory = $authenticationFactory;
    }

    /**
     * @param mixed $data
     * @return mixed|string
     */
    public function setData($data)
    {
        try {
            $return = [];
            $code = null;
            if (isset($data)) {
                if (isset($data['integration_list'])) {
                    $integration = \Ced\VendorVarification\Helper\ApiEndPoint::INTEGRATION;
                    return ['success' => $integration];
                } elseif (isset($data['store_url'])) {
                    $collection = $this->authenticationFactory
                        ->create()
                        ->getCollection()
                        ->addFiledToFilter('store_urls', $data['store_url']);
                    foreach ($collection as $call) {
                        $return[] = $call->getMarketPlace();
                    }
                    return ['success' => $return];
                }
            }
        } catch (\Exception $e) {
            $error = $e->getMessage();
            $return['error'] = $error;
        }
        return [$return];
    }

    public function endpoints($data)
    {
        /**
         * @param mixed $data
         * @return mixed|string
         */
        try {
            $return = [];
            if (isset($data)) {
                if (isset($data['store_url'])) {
                    $collection = $this->authenticationFactory
                        ->create()
                        ->getCollection()
                        ->addFiledToFilter('store_urls', $data['store_url']);
                    foreach ($collection as $call) {
                        $marketPlace = $call->getMarketPlace();
                        $urls = \Ced\VendorVarification\Helper\ApiEndPoint::URLS;
                        if(isset($urls[$marketPlace])) {
                            $return[$marketPlace] =  $urls[$marketPlace];
                        }
                    }
                    return ['success' => $return];
                }
            }
        } catch (\Exception $e) {
            $error = $e->getMessage();
            $return['error'] = $error;
        }
        return [$return];

    }
}
