<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_VendorVarification
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\VendorVarification\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Setup\Exception;

class ApiEndPoint extends \Magento\Framework\App\Helper\AbstractHelper
{

    const TYPE = 'sandbox';
    const URLS = [
        'Aliexpress' => [
            'live' => [
                'AUTHENTICATION' => 'https://aliexpress-channel.remote.sellernext.com/apiconnect/request/auth?sAppId=1',
                'REFRESH_TOKEN' => 'https://aliexpress-channel.remote.sellernext.com/magentohome/request/getNewRefershToken',
                'WEB_HOOK_URL' => 'https://phfnhcoq12.execute-api.eu-west-2.amazonaws.com/live/magento_webhook_live'
            ],
            'sandbox' => [
                'AUTHENTICATION' => 'https://dev.common-remote.cedcommerce.com/apiconnect/request/auth?sAppId=2',
                'REFRESH_TOKEN' => 'https://dev.common-remote.cedcommerce.com/magentohome/request/getNewRefershToken',
                'WEB_HOOK_URL' => 'https://cr0gdi1hs5.execute-api.ap-southeast-1.amazonaws.com/v1/magento_webhook_py'
            ],
            'local' => [
                'AUTHENTICATION' => 'http://remote.local.cedcommerce.com:8080/apiconnect/request/auth?sAppId=16',
                'REFRESH_TOKEN' => 'http://remote.local.cedcommerce.com:8080/magentohome/request/getNewRefershToken',
                'WEB_HOOK_URL' => 'https://cr0gdi1hs5.execute-api.ap-southeast-1.amazonaws.com/v1/magento_webhook_py'
            ]
        ],
        'TikTok' => [
            'sandbox' => [
                'AUTHENTICATION' => 'https://connector-dev.demo.cedcommerce.com/remote/public/apiconnect/request/auth?sAppId=36',
                'REFRESH_TOKEN' => ''
            ]
        ]
    ];

    const INTEGRATION = [
            'TikTok' => [
                'image' => 'https://demo2.cedcommerce.com/magento2/integration-sa/pub/media/catalog/product/3/2/3256804084911951_1.jpg',
                'name' => 'TikTok Integration',
                'contact' => 'TikTok Integration',
                'description' => 'TikTok Integration',
            ],
            'Aliexpress' => [
                'image' => 'https://demo2.cedcommerce.com/magento2/integration-sa/pub/media/catalog/product/3/2/3256804084911951_1.jpg',
                'name' => 'Aliexpress Integration',
                'contact' => 'Aliexpress Integration',
                'description' => 'Aliexpress Integration',
            ]
        ];

    public function __construct(
        Context $context
    ) {
        parent::__construct($context);
    }
}
